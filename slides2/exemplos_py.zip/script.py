# -*- coding: latin-1 -*-

# Tudo que vem ap�s o '#' na linha � ignorado pelo interpretador, menos na primeira linha que � a codifica��o do arquivo :)
# � boa pratica de programa��o Antes de come�ar o programa colocar seu nome, data da ultima vers�o, e uma descri��o do que ira fazer
# Este � um tutorial simples de python: Numpy e Matplotlib que funciona por meio de exemplos
# Viviane Maranh�o, Mar�o de 2012

from math import *		#importa todos os metodos do pacote math
caminho = "./"				#atribui uma string � variavel caminho
caminho + "arquivo.txt"	#concatena as duas strings

#Opera��es matem�ticas
2+3					#Soma
2-3					#Subtra��o
2*3					#Multiplica��o
2/3.0					#Divis�o (o denominador tem que ser double, sen�o ele trunca o resultado)
20%2				#Resto da divis�o
floor(0.2)			#Parte inteira inferior do n�mero (usa o pacote math)
log(2)				#Logar�tmo  (usa o pacote math)
log10(2)				#Logar�timo na base 10  (usa o pacote math)
abs(-2)				#M�dulo
exp(2)				#Exponencial (usa o pacote math)
sqrt(2)				#Raiz quadrada (usa o pacote math)
2**3					#Pot�ncia
pow(2,3)			#Pot�ncia
num1 = 2			#Atribui��o � vari�vel
num2 = 3			#Atribui��o com '<-' n�o funciona no python
num1*num2		#Multiplica��o das vari�veis
sin(math.pi)				#Seno de pi  (usa o pacote math)



# Criando vetores (como lista, sem numpy)
x=[1,2,4,1.2,1.2,3,4]	#atribui ao vetor x esses valores
x 								#mostra o conte�do do vetor x
x[0]							#primeiro valor de x. No python come�a no 0
len(x)						#dimens�o de x
from numpy import *
array(x)-2							#subtrai 2 de cada elemento de x
array(x)/3							#divide cada elemento de x por 3

#Tipo do dado								
type(caminho)		#tipo d e 'caminho'
caminho.isspace()	#caminho cont�m s� espa�os? (vale para strings)
caminho.isdigit()		#caminho cont�m s� numeros? (vale para strings)
caminho.isalpha()	#caminho cont�m s� chars? (vale para strings)
# Matrizes-> usa numpy
m1 = arange(10).reshape(5,2)			#Matriz 5x2
m2 = arange(10).reshape(2,5)			#Matriz 2x5
m3 = arange(20,10,-1).reshape(2,5)		#Outra matriz 2x5
m3 + m2 								#Soma de matrizes
#m1 + m2								#Erro
dot(m1,m2)						    	#Multiplica��o de matrizes
m3.transpose()							#Transposta
m4 = column_stack((m1, ones(5)*11))		#Acrescenta coluna de 11s
m5 = row_stack((m4, ones(3)*22))		#Acrescenta linha de 22s
m5[1,2]								    #Elemento da matriz

#Leitura de arquivo como texto
f = open("entrada.txt"); arq = f.readlines(); f.close()	# L� o arquivo e atribui � arq
arq 												# Imprime a vari�vel
arq[1] 												# Primeira linha de dados
arq[2] 												# Segunda linha
arq[3] 												# Terceira linha
arq[4] 												# Quarta linha
linha = arq[4].split()						        #Separa em varios
linha  												# mostra o valor da vari�vel, se estiver no modo prompt

#Leitura de arquivo como dataframe (matriz que pode misturar tipos)
arq2 = loadtxt("entrada.txt", skiprows=1)	# L� o arquivo e ignora a coluna com o header
arq2[3]										# Segunda linha
zip(*arq2)[3]				    			# Segunda coluna	

#N�meros alteat�rios
help(random.uniform)							#ajuda para a fun��o random.uniform
random.uniform(2,10,20)							#gera 20 n�meros  aleat�rios entre 2 e 10
random.uniform(size=20)  						#gera 20 n�meros  aleat�rios entre 0 e 1
x=map(round,(5*random.uniform(size=20)+0.5)) 	#gera 20 n�meros  aleat�rios inteiros entre 1 e 5
x1=random.random_integers(1,5,20)               #outra forma de gerar 20 n�meros  aleat�rios inteiros entre 1 e 5

#Medindo o tempo
#%timeit for i in range(0,1000000): random.exponential(1) #Vendo o tempo que leva para gerar 1000000 numeros aleatorios, 1 por 1 (no ipython)
#%timeit random.exponential(size=1000000)				 #Vendo agora, gerando do jeito esperto (no ipython, est� comentado pois nao vai rodar como script assim)

from scipy import *                 #Estat�sticas
scipy.stats.itemfreq(x)				#mostra os valores de x e suas freq��ncias
zip(*scipy.stats.itemfreq(x))[1]	#mostra s� as freq��ncias
scipy.stats.itemfreq(x)	[0,1]		#mostra s� a freq��ncia do primeiro elemento de x
ni=zip(*scipy.stats.itemfreq(x))[1]	#atribui a ni as frequenicas de x
sum(ni)								#somat�ria dos valores
mean(x)								#M�dia
var(x)								#Vari�ncia
std(x)								#Desvio Padr�o
min(x)								#M�nimo
max(x)								#M�ximo

#La�os
vec=[]      			#inicializa a lista unidimencional. N�o � preciso especificar o tamanho
for i in range(0,100):	#for (i=1; i<=100; i++)
    vec.append(i)		#atribui um valor para cada posi��o. 


vec						#mostra na tela vec. Esse tipo de coisa s� funciona usando o prompt, se rodar dentro do script n�o aparece nada
sort(vec)[::-1]       	#ordena vec do maior para o menor

#Condi��es
n1 = 3
n2 = n1 if n1<10 else n1/10	#Como o operador tern�rio do C
n2
n1 = 34
if n1 % 10 == 4: n2 = 20	#Outra forma de fazer condi��o
n2

#Ambiente de trabalho
dir()							#lista os vetores e fun��es criadas e carregadas
del vec							#remove a varivavel
dir()							#verifica se removeu

# Distribui��es
x = random.normal(2,1,50)		#cria 50 observa��es de uma normal com media 2 e d.p. 1
y = random.normal(10,1,30)		#cria 30 observa��es de uma normal com media 10 e d.p. 1
scipy.stats.kstest(x, 'norm')	#testa se x tem distribui��o normal

# Gr�ficos
hist(x)							#faz o histograma de x, na tela se estiver no ipython com pylab
hist(y)							#faz o histograma de y, na tela se estiver no ipython com pylab

plot(x, color= 'red')	        #faz o gr�fico de x como linhas em vermelho
plot(y, 'bo')                 	#adiciona o gr�fico de y, como linhas e pontos, em azul
savefig(caminho+"grafico.png")	#salva a figura aberta no arquivo

#Criando fun��es
def soma(a, b): #soma � uma fun��o que recebe 2 argumentos: a e b
	x = a + b	#opera��es...
	return (x)	#o que a fun��o devolve

soma(1,2)		#chama a fun��o

#plotar fun��es. ver ?plot e ?par para conhecer todas as op��es de gr�ficos
x1 = arange(0.5,51, 0.5)				# Cria uma sequencia de 0 a 50 com 101 elementos
y1 = 1 - (1/x1) * sin(x1)				# Atribui o valor da fun��o para cada x1 em y1
plot(x1, y1, '--')						# Faz o gr�fico de fun��o acima com uma linha pontilhada

x2 = arange(80, 120.2, 0.4)				# Cria uma sequencia de 80 a 120 com 101 elementos
y2 = scipy.stats.norm.pdf(x2, 100,5)    # Outra fun��o (normal (100,25))
plot(x2, y2, '^')				        # Faz outro gr�fico, de pontos, com triangulos
y3 = scipy.stats.norm.pdf(x2, 90,9) 	# Outra fun��o (normal (90,81))
plot(x2, y3, "orange")	    	        # Acrescenta no mesmo gr�fico.

#Carregando pacotes
#import "pacote"							#Carrega o pacote. 

print x								#imprime x na tela. Esse comando imprime na tela mesmo que esteja rodando dentro de um script
nome_arq = caminho + "saida.txt"	#cria o nome do arquivo com o caminho
f = open(nome_arq, 'a')             #abre o arquivo modo append
f.write(str(x))	        			#imprime x nele.
f.write("\nlinha nova")				#adiciona uma linha no arquivo sem sobrescrever
f.close()

#Rodando scripts
#execfile("script.py")						#Chama o script com este nome. As fun��es ficam carregadas


