vendas = {1: "volkswagen", 2: "chevrolet", 3: "fiat", 4:"hiunday"}
print(vendas.keys())
print(vendas.values())
print(vendas.items())