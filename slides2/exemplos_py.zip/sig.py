# -*- coding: utf-8 -*-
"""
Spyder Editor

This temporary script file is located here:
E:\WinPython-32bit-2.7.6.4\settings\.spyder2\.temp.py
"""

class Sinal:
 def __add__(self, other):
 # Returns: New signal that is the sum of self and other.	
     pass
 	
 def __rmul__(self, scalar):
 # Returns: New signal that is self scaled by a constant.	
      pass
 	
 def __mul__(self, scalar):
 # Returns: New signal that is self scaled by a constant.	
      pass
    
 def plot(self, start=0, end=100, plotWin=None, title='Signal value versus time'):
     pass
 	
 def period(self, n=None, z=None):
 # Returns: an estimate of the period of the signal, or 'aperiodic' if it can't get a good estimate	
      pass
 	
 def crossings(self, n=None, z=None):
 # Returns: a list of indices into the data where the signal crosses the z value, up through time n	
     pass
 	
 def mean(self, n=None):
 # Returns: sample mean of the values of the signal from 0 to n	
     pass
 	
 def samplesInRange(self, lo, hi):
 # Returns: list of samples of this signal, from lo to hi-1
     pass

class SinalCte(Sinal): 
  def __init__(self, cte): 
    self.cte  =  cte 
  def amostra(self, n): 
    return  self.cte

class SinalImpulsoUnit(Sinal): 
  def amostra(self, n): 
    if n == 0: 
      return 1 
    else: 
      return 0

class SinalDegrauUnit(Sinal): 
  def amostra(self, n): 
    if n >= 0: 
      return 1 
    else: 
      return 0
 
dc = SinalCte(5)
print dc.amostra(10)
print dc.amostra(50)
d = SinalImpulsoUnit()
print d.amostra(-1), d.amostra(0), d.amostra(10)
u = SinalDegrauUnit()
print u.amostra(-1), u.amostra(0), u.amostra(10)
print u.amostra(range(-3,3))