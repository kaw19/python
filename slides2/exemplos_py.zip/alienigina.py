alien_0 = {'cor': 'verde', 'pontos': 5}
print(alien_0['cor'])
print(alien_0['pontos'])