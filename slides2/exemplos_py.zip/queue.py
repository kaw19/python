# -*- coding: utf-8 -*-
"""
Created on Sun Jan 18 16:14:04 2015

@author: kaw
"""

class Queue:
    def __init__(self):
        self.items = []

    def __getitem__(self,index):
        return self.items[index]
        
    def isEmpty(self):
        return self.items == []

    def enqueue(self, item):
        #self.items.insert(0,item)
        self.items.append(item)

    def dequeue(self):
        #return self.items.pop()
        temp = self.items[0]
        self.items.remove(self.items[0])
        return temp

    def size(self):
        return len(self.items)
        
    def remove(self,item):
        while item in self: 
            self.items.remove(item)
