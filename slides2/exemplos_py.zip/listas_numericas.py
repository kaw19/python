for valor in range(1,10):
	print(valor,end=' ')