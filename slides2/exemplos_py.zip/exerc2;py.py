nomes = ["mário",'joana','joão','mariana']
print(nomes[0].title(), "seja bem-vindo(a) ao curso de Python!")
print(nomes[1].title(), "seja bem-vindo(a) ao curso de Python!")
print(nomes[2].title(), "seja bem-vindo(a) ao curso de Python!")
print(nomes[3].title(), "seja bem-vindo(a) ao curso de Python!")