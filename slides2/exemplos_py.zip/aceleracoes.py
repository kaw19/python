acX, acY, acZ = 10, 20, 30.5
print("Acelerações: X =", acX, " Y =", acY, " Z =",acZ)