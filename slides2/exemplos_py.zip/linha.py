# -*- coding: utf-8 -*-
""" linha.py
Created on Sat Apr 23 21:38:20 2022
Fonte: https://www.youtube.com/watch?v=YOQvnhPEPUU&t=431s
@author: profc
"""
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch

c = canvas.Canvas('linha.pdf')
x1, y1 = 0, 8*inch
x2, y2 = 7*inch, 8*inch
c.setStrokeColorRGB(1,0,0) # linha vermelha
c.translate(inch,inch)     # translada a origem para (1",1")
c.setLineWidth(10)         # espessura da linha: 10 pontos
c.line(x1,y1,x2,y2)
c.setFontSize(20)
c.drawString(200,600,"Olá Pessoal!")
c.save()
