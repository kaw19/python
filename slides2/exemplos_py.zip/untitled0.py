# coding: utf-8

from numpy import array, poly, arange, reshape
from control.matlab import pzmap, tf, impulse, step
from matplotlib.pylab import stem, figure, axis, Circle, Rectangle, gca, grid, title
#def circ(raio,teta):
#  from numpy import cos, sin, pi
#  return raio*cos(teta), raio*sin(teta)
#ang = arange(0,2*pi,0.01); r =1.
#plot(*circ(r,ang), c='r'); axis('scaled')

# FunÃ§Ã£o de TransferÃªncia
num = array([1])        # coeficientes do pol. do numerador de H(z)
den = poly([-1,-2])     # coeficientes do pol. do denominador de H(z)
Hz = tf(num,den,True)   # cria SLITD definido pela FunÃ§Ã£o de Transf.

# Região de Convergência
figure()
base = Rectangle((-1.5,-1.5),3,3,hatch='.',fill=False,zorder=-2)
gca().add_patch(base)
rdc = Circle((0,0),radius=1.,facecolor='w',edgecolor='r',zorder=-1) 
gca().add_patch(rdc)

# Mapa de Polos e Zeros da FunÃ§Ã£o de TransferÃªncia
pzmap(Hz,title='Mapa de Polos e Zeros')
axis('scaled'); axis([-1.5,1.5,-1.5,1.5])

# Resposta ao Impulso UnitÃ¡rio
n = arange(0,15)
h,n = impulse(Hz,n)
figure(); stem(n,reshape(h,n.shape)); grid('on'); title(u'Resp. ao Impulso Unitário')

# Resposta ao Degrau UnitÃ¡rio
n = arange(0,15)
s,n = step(Hz,n)
figure(); stem(n,reshape(s,n.shape)); grid('on'); title(u'Resp. ao Degrau Unitário')
