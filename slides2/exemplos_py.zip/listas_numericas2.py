for valor in range(10):
	print(valor,end=' ')