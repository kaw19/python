ling_favorita = {
    'márcia': 'java', 
    'joão': 'python', 
    'rubens': 'c', 
    'ana': 'fortran'
    }
amigos = ['rubens', 'márcia']
for nome in ling_favorita.keys():
    print(nome.title())
    if nome in amigos:
        linguagem = ling_favorita[nome].title()
        print(f"\t{nome.title()}, eu vi que você gosta de {linguagem}!")