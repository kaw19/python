jogadores = ['maria', 'marta', 'miguel', 'joão', 'eli']
print(jogadores[:2])
print(jogadores[2:])
print(jogadores[-2:])
print(jogadores[:-2])