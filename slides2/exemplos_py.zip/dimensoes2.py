dimensoes = (200, 50, 120)
for dimensao in dimensoes:
	print(dimensao)