dimensoes = (200, 50)
print(dimensoes[0])
print(dimensoes[1])