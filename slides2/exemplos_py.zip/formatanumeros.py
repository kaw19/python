a = 1_000_000_000
b = f'Prêmio: R$ {a:,.2f}'
print(b.replace('.','^').replace(',','.').replace('^',',')) 