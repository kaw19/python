for n in range(5):
    print u'Ol� mundo!'