mensagem = "Olá Pessoal!"
print(mensagem)
