from reportlab.pdfgen import canvas

c = canvas.Canvas("pag_simples.pdf")
c.drawString(100,750,"Bem-vindo ao Reportlab!")
c.save()