# solução do exercício 2-1 do livro "Python Crash Course"
mensagem = "Curso de Introdução à Ling. Python"
print(mensagem)