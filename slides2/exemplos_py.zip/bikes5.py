motos = ['honda', 'yamaha', 'suzuki']
print(motos)
primeira_moto = motos.pop(0)    # .pop(ind) é um método de remoção de item da lista
print(f"A primeira moto que eu possuí foi uma {primeira_moto.title()}.")
print("A primeira moto que eu possuí foi uma ", primeira_moto.title(), ".", sep="")
print(motos)