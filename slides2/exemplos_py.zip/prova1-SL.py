#-*- coding: utf-8 -*-
#"""
#Created on Fri Mar 20 19:01:06 2015
#@author: 20092003800637
#"""
#from numpy import array
#from matplotlib.pyplot import plot, grid
#t=array([-1,0,1,2,3,4,5,6,6])
#r=array([0,0,0,0,0,0,0,0,-1])
#t1=array([6,15])
#r1=array([-1,.5])
#t2=array([15,24])
#r2=array([.5,0])
#grid('on')
#plot(t,r,'b'),plot(t1,r1,'b'), plot(t2,r2,'b')
#
#import numpy as np
#import matplotlib.pylab as plt
#
#def degrau(x):
#  y = np.zeros(len(x))
#  for i in xrange(0,len(x)):
#    if x[i] >= 0:
#      y[i] = 1.
#  return y
#
#t = np.arange(0,30)
#x = (degrau(t-6)-degrau(t-12))*((0.166*t)-2)
#plt.grid ('on')
#plt.plot(t,x,'b')
#plt.figure()
#x1 = (degrau(t-12)-degrau(t-15))*((0.166*t)-2)
#plt.grid ('on')
#plt.plot(t,x1,'b')
#plt.figure()
#y= x+x1
#plt.grid ('on')
#plt.plot(t,y,'y')
#plt.figure()
#x2 = (degrau(t-15)-degrau(t-24))*((-.055*t)+1.333)
#plt.grid ('on')
#plt.plot(t,x2,'b')
#plt.figure()
#y1 = x+x1+x2
#plt.grid ('on')
#plt.plot(t,y1,'y')
#plt.figure()
#plt.grid ('on')
#plt.plot(-t,y1,'y')
#plt.figure()
#plt.grid ('on')
#plt.plot(6-t,y1,'y')
#plt.figure()

# -*- coding: utf-8 -*-
#"""
#Created on Fri Mar 20 19:19:24 2015
#@author: 20141003802453
#"""
# 
#import numpy as np
#import matplotlib.pylab as plt
# 
#x = 0
#def degrau(x):
#   y = np.zeros(len(x))
#   for i in xrange(0,len(x)):
#      if x[i] >= 0:
#         y[i] = 1.
#   return y
# 
##grafico de x(t)
#t = np.arange(0,24+0.1,0.1)
#x1 = ((degrau(t-6))-(degrau(t-15)))*((t/(6.))-2.)
#x2 = ((degrau(t-15))-(degrau(t-24)))*((t/(-18.))+4/3.)
#plt.figure(1)
#plt.subplot(3,1,1); plt.plot(t,x1+x2)
#plt.ylim(-1.1,0.6); plt.xlim(-1.,25); plt.title(u'x(t)'); plt.grid('on')
# 
##grafico de x(-t)
#t = np.arange(0,24.1,0.1)
#n = np.arange(-24,0.1,0.1)
#x1 = ((degrau(t-9))-(degrau(t-18)))*((t/(-6.))+2)
#x2 = ((degrau(t))-(degrau(t-9)))*((t/(18.)))
#plt.figure(1)
#plt.subplot(3,1,2); plt.plot(n,x1+x2)
#plt.ylim(-1.1,0.6); plt.xlim(-25,1.); plt.title(u'x(-t)'); plt.grid('on')
# 
##grafico de x(6-t)
#t = np.arange(0,24.1,0.1)
#n = np.arange(-30,-5.9,0.1)
#x1 = ((degrau(t-9))-(degrau(t-18)))*((t/(-6.))+2)
#x2 = ((degrau(t))-(degrau(t-9)))*((t/(18.)))
#plt.figure(1)
#plt.subplot(3,1,3); plt.plot(n,x1+x2)
#plt.ylim(-1.1,0.6); plt.xlim(-31,0); plt.title(u'x(6-t)'); plt.grid('on')


#import numpy as np
#import matplotlib.pylab as plt
# 
#def degrau(x):
# y = np.zeros(len(x))
# for i in xrange(0,len(x)):
#      if x[i] >= 0:
#          y[i] = 1.
# return y
# 
#t = np.arange(0,25,.01)
#r1 = ((t/6.)-2.) * (degrau(t-6.)-degrau(t-15.))
#r2 = ((-t/18.)+(4./3.))*(degrau(t-15.)-degrau(t-24.))
#x = r1 + r2
#plt.plot(t,x)                       # sinal original: x(t)
#plt.figure(); plt.plot(-t,x)        # sinal revertido no tempo: x(-t)
#plt.figure(); plt.plot(6-t,x)       # sinal rev. e desloc. no tmepo: x(6-t)

#Plot de x(t)
import numpy as np
import matplotlib.pylab as plt
 
x= np.arange(0,25.)
 
y1=(((1.5*x)-18)/9)
y2=(((-0.5*x)+12)/9)
 
r1= np.array([0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0])*y1
r2= np.array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1])*y2
 
plt.plot(x,r1+r2)
 
#Plot de x(-t)
import numpy as np
import matplotlib.pylab as plt
 
x= np.arange(0,25)
 
y1=(((1.5*x)-18)/9)
y2=(((-0.5*x)+12)/9)
 
r1= np.array([0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0])*y1
r2= np.array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1])*y2
 
plt.plot(x*-1,r1+r2)