# -*- coding: utf-8 -*-
""" Exibe círculos: preenchido e tracejado.
@author: kaw, Set/2015
"""

from matplotlib.pyplot import figure, subplot, plot, grid, gcf, axes
from matplotlib.patches import Circle, Rectangle
# gcf() significa 'Get Current Figure'
# gca() significa 'Get Current Axis'

# cria um círculo preenchido de azul, origem (.5,.5) e raio .4, mas não mostra
circulo = Circle((.5,.5),.4,color='b',visible=True)  
# obtem a referência da figura corrente
fig1 = gcf()                             
# retorna (ou cria) ref. de eixos e acrescenta 'artist' aos eixos correntes
# (o círculo preenchido, neste caso)
fig1.gca().add_artist(circulo)               
axes().set_aspect('equal')

#%%
fig2 = figure()
ax2 = fig2.add_subplot(111, aspect='equal'); grid('on')
ax2.add_patch(Circle((0.5, 0.5), 0.45, fill=False, linestyle='dashed')) # sem preenchimento

#%% SLITD não causal
fig3 = figure()
#ax3 = fig3.add_subplot(111, aspect='equal')
eixo3 = subplot(111, aspect='equal'); grid('on'); r = 0.45
eixo3.axis((-1.,1.,-1.,1.))
p = Circle((0., 0.), r, fill=True, alpha=0.2, linestyle='dashed',edgecolor='black',linewidth=2)
eixo3.add_patch(p)
fig3.canvas.draw()

#%% SLITD causal
#from matplotlib.pyplot import figure, subplot, grid
#from matplotlib.patches import Circle, Rectangle
fig4 = figure()
ax4 = fig4.add_subplot(111, aspect='equal')
ax4.add_patch(Rectangle((-1., -1.), 2., 2., alpha=0.2, fill=True))
ax4.add_patch(Circle((0., 0.), 0.5, color='w', fill=True, 
                     linestyle='dashed',edgecolor='black',linewidth=3))
fig4.canvas.draw()
ax4.axis((-1.,1.,-1.,1.)); grid('on')
# polos e zeros
plot(0.3,-0.3,'rx', markeredgewidth=2.)
plot(0.3,0.3,'rx', markeredgewidth=2.)
plot(-0.6,0.,'bo', markeredgewidth=2.)

