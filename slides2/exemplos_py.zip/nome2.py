nome = "João José"
print(nome.upper())
print(nome.lower())