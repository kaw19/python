# -*- coding: utf-8 -*-
""" wraptext.py
Created on Sat Apr 23 15:34:15 2022
Fonte: https://stackoverflow.com/questions/4726011/wrap-text-in-a-table-reportlab
@author: profc
"""

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.lib import colors

width, height = A4
styles = getSampleStyleSheet()
styleN = styles["BodyText"]
styleN.alignment = TA_RIGHT
styleBH = styles["Normal"]
styleBH.alignment = TA_CENTER

def coord(x, y, unit=1):
    x, y = x * unit, height -  y * unit
    return x, y

# Cabeçalhos
hdescricao = Paragraph('''<b>descrição</b>''', styleBH)
hpartida = Paragraph('''<b>partida</b>''', styleBH)
hqtde = Paragraph('''<b>quantidade</b>''', styleBH)
hpr_unit = Paragraph('''<b>preço unitário</b>''', styleBH)
hpr_total = Paragraph('''<b>preço total</b>''', styleBH)

# Textos
descricao = Paragraph('parágrafo longo', styleN)
partida = Paragraph('1', styleN)
qtde = Paragraph('120', styleN)
pr_unit = Paragraph('$ 52,00', styleN)
pr_total = Paragraph('$ 6240,00', styleN)

data= [[hdescricao, hpartida, hqtde, hpr_unit, hpr_total],
       [descricao, partida, qtde, pr_unit, pr_total]]

table = Table(data, colWidths=[2.1 * cm, 2.7 * cm, 2.5 * cm, 3 * cm, 3 * cm])

table.setStyle(TableStyle([
                       ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                       ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                       ]))

c = canvas.Canvas("wraptexto.pdf", pagesize=A4)
table.wrapOn(c, width, height)  # larg: 595.27 pt; alt: 841.89
table.drawOn(c, *coord(1.8, 3.6, cm))
c.save()