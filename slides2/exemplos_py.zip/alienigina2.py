alienigina = {'cor': 'verde', 'pontos': 5}
print(alienigina)              # dicionário original

alienigina['posicao_x'] = 0
alienigina['posicao_y'] = 35
print(alienigina)              # dicionário modificado