linguagem_favorita = {
    'márcia': 'java', 
    'joão': 'python', 
    'rubens': 'c', 
    'ana': 'fortran'
    }
print(linguagem_favorita)

linguagem = linguagem_favorita['joão'].title()
print(f"A linguagem favorita do João é {linguagem}.")

linguagem = linguagem_favorita.get('maria','**Usuário não cadastrado!**')
print(f"A linguagem favorita de Maria é {linguagem}.")