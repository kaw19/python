print("Python  ".rstrip())
print("  Python".lstrip())
print("  Python  ".strip())