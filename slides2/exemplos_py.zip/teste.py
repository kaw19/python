# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 12:27:24 2015

@author: kaw
"""

import matplotlib.pyplot as plt
import numpy as np

t = np.arange(-10,10)
r = np.zeros((1,10))
p = np.ones((1,10))
plt.ylim(-2,2), plt.xlim(-11,11)
# comando com erro: plt.stem(t[:],r), plt.stem(t[:],p)
# Solução 1
plt.stem(t[:10],r[0]), plt.stem(t[10:],p[0])

plt.figure()

# Solução 2
t = np.arange(-10,10)
u = t>=0
plt.stem(t,u)
plt.ylim(-2,2), plt.xlim(-11,11)
