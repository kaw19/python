tempos = list(range(10))
print(tempos)
