motos = []
motos.append('honda')
motos.append('yamaha')
motos.append('suzuki')
print(motos)
