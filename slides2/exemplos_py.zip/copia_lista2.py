jogadores = ['maria', 'marta', 'miguel', 'joão', 'eli']
reservas  = jogadores
print(jogadores, reservas)
jogadores.append("zico")
print(jogadores, reservas)