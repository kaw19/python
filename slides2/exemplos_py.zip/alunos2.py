alunos = {'joão': 10, 'maria': 2}
alunos['ana'] = 8.5
# print(alunos)
alunos.update({'maria':6})
alunos.update({'carlos':5.2})
# print(alunos)

for aluno in alunos:
	print(f"Nota do aluno(a) {aluno.capitalize()} é {alunos[aluno]}")
