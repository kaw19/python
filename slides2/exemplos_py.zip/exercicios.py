# # Exercício 1 - Slides Cap.4
# for num in range(1,21):
# 	print(num, end=' ')
# print()

# # Exercício 5 - Slides Cap.4
# for num in range(3,31,3):
# 	print(num, end=' ')
# print()

# # Exercício 7 - Slides Cap.4
# cubos = [num**3 for num in range(1,11)]
# print(cubos)

# Exercício 1 - Buffet - Cap.4
pratos = ('feijoada','churrasco','lasanha','galinha à cabidela','macarronada')
print("Menu 1",'-'*30)
for prato in pratos:
	print(prato, end=', ')
# pratos[0] = 'arroz com pequi'

pratos = ('arroz com pequi','churrasco','arroz carreteiro','galinha à cabidela','macarronada')
print("\nMenu 2",'-'*30)
for prato in pratos:
	print(prato, end=', ')
print()