comidas = "arroz,feijão,batata,carne,cenoura,vagem"
comidas2 = "arroz;feijão;batata;carne;cenoura;vagem"
# criação de uma lista de ALIMENTOS a partir da string COMIDAS
alimentos = comidas2.split(';')
print(alimentos)
print(f"Eu gosto de comer {alimentos[0]}, {alimentos[1]} e {alimentos[3]}.")