alienigina = {'cor': 'verde', 'pontos': 5, 'posicao_x': 0, 'posicao_y': 25}
print(alienigina)
del alienigina['pontos']
print(alienigina)