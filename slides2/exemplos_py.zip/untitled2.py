# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 07:48:09 2015

@author: kaw
"""
import numpy as np
import matplotlib.pylab as mpl

t = np.arange(0.,2.,0.001)
xa = np.sin(2*np.pi*5*t)    # sinal analógico de 5 Hz
mpl.plot(t,xa,'k'); mpl.hold('on')

fs = 15
ts = np.arange(0.,2.,1./fs)
xs1=np.sin(2*np.pi*5*ts)    # sinal amostrado com 15 Hz
mpl.plot(ts,xs1,'bo-')

fs = 7.5
ts = np.arange(0.,2.,1./fs)
xs2= np.sin(2*np.pi*5*ts)   # sinal amostrado com 7,5 Hz
mpl.plot(ts,xs2,'ro-') 