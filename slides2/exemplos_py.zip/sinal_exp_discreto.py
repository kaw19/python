# -*- coding: utf-8 -*-
""" Traçado de sinal rampa """
from numpy import arange, exp
from matplotlib.pylab import stem, title, xlabel, ylabel, grid

n = arange(-5,6)     # n = 0:10
x = n/5.
stem(n,x)            # stem(n,x)
title('Rampa Discreta')
xlabel('n')
ylabel('x[n] = n')
grid('on')

#import numpy as np
#import matplotlib.pylab as plt
#
#n = np.arange(0,11)     # n = 0:10
#x = np.exp(-2*n)        # x = exp(-2*n)
#plt.stem(n,x)            # stem(n,x)
#plt.title('Exponencial Discreto')
#plt.xlabel('n')
#plt.ylabel('exp(-2*n)')
#plt.grid('on')