# -*- coding: utf-8 -*-
""" Lê arquivo de dados do MATLAB (.mat)
    @author: Prof. Cláudio, Fev/2015    """
import scipy.io as sio
import matplotlib.pylab as plt
s = sio.loadmat('ecg.mat')
plt.plot(s['ecg4'][0])
