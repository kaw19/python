# -*- coding: utf-8 -*-
""" relatorio1.py
Created on Sat Apr 23 09:34:25 2022

@author: profc
"""

from reportlab.platypus.doctemplate import SimpleDocTemplate
from reportlab.platypus import Paragraph, Spacer
import reportlab.lib.styles
from reportlab.lib.units import inch

estoque = {'arroz de cerqueiro':540,'feijão':230,'farinha':330,
           'açúcar':220,'café':380,'ovo':130,'carne':650}
doc = SimpleDocTemplate("produtos.pdf")
estilos = reportlab.lib.styles.getSampleStyleSheet()
cabecalho = Paragraph("Estoque de Produtos", estilos['Heading1']) 
Catalogo = []
Catalogo.append(cabecalho)
estilos['Normal'].fontSize = 14
estilos['Normal'].fontName = 'Courier'
s = Spacer(1, 0.25*inch)
for nome,qtde in estoque.items():
    p = Paragraph("%10s %5d" % (nome.capitalize(), qtde), estilos['Normal'])
    Catalogo.append(p)
    Catalogo.append(s)
doc.build(Catalogo)
print("Arquivo PDF 'produtos.pdf' foi gerado!")

# texto = '''Você é acusado de que no dia 28 de maio de 1970, você fez
# voluntariamente, ilegalmente e com malícia de premeditação, publicar um
# suposto livro de frases inglês-húngaro com a intenção de causar uma
# Violação da paz. Como você se declara?'''
# estilo1 = ParagraphStyle('Normal')
# parabox(texto, estilo1, 'O $ParagraphStyle$' padrão.)