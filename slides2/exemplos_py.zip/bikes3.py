motos = ['honda', 'yamaha', 'suzuki']
print(motos)
motos.append('ducati')   # inclui item ao final da lista
print(motos)