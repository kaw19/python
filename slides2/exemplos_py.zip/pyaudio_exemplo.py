# -*- coding: utf-8 -*-
"""PyAudio Example: Play a WAVE file.
   PyAudio is a cross-platform sound card interface library.
   O pacote PYAUDIO foi instalado via WCP (GUI do Winpython Packages Manager)
   Obs.: O nome do arquivo wheel teve que ser alterado de 
   PyAudio-0.2.8-cp35-none-win32.whl  para  PyAudio-0.2.8-cp35-none-any.whl
"""

import pyaudio as pa
import wave
#import sys

CHUNK = 1024

#if len(sys.argv) < 2:
#    print("Plays a wave file.\n\nUsage: %s filename.wav" % sys.argv[0])
#    sys.exit(-1)

#wf = wave.open(sys.argv[1], 'rb')
wf = wave.open("C:\Users\kaw\Music\music\I'll be back (The Terminator).wav", 'rb')
p = pa.PyAudio()
stream = p.open(format=p.get_format_from_width(wf.getsampwidth()),
                channels=wf.getnchannels(),
                rate=wf.getframerate(),
                output=True)

data = wf.readframes(CHUNK)

while data != '':
    stream.write(data)
    data = wf.readframes(CHUNK)

stream.stop_stream()
stream.close()

p.terminate()