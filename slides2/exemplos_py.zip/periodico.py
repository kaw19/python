# -*- coding: utf-8 -*-
""" Sinal periódico contínuo x(t), a partir da combinação linear 
    de sinais senoidais harmonicamente relacionados.
@author: Prof. Cláudio, Ago-2015 """
from numpy import linspace, ones, cos, pi
from matplotlib.pylab import subplot, plot, grid, xlabel, ylabel, axis
t  = linspace(-5,5,1000)
x0 = ones((1000));  x1 = 0.5*cos(2.*pi*t)
x2 = cos(4.*pi*t);  x3 = 2./3.*cos(6.*pi*t)

subplot(4,1,1); plot(t,x0,'k'); grid()
ylabel(r'$x_0(t)$'); axis((-5,5,-1,3.5))
subplot(4,2,3); plot(t,x1,'r'); grid()
ylabel(r'$x_1(t)$'); axis((-5,5,-1,3.5))
subplot(4,2,4); plot(t,x0+x1);  grid()
ylabel(r'$x_0(t)+x_1(t)$'); axis((-5,5,-1,3.5))
subplot(4,2,5); plot(t,x2,'g'); grid()
ylabel(r'$x_2(t)$'); axis((-5,5,-1,3.5))
subplot(4,2,6); plot(t,x0+x1+x2); grid()
ylabel(r'$x_0+x_1+x_2$'); axis((-5,5,-1,3.5))
subplot(4,2,7); plot(t,x3,'c'); grid()
ylabel(r'$x_3(t)$'); xlabel('t'); axis((-5,5,-1,3.5))
subplot(4,2,8); plot(t,x0+x1+x2+x3); xlabel('t'); grid()
ylabel(r'$x(t) = x_0+x_1+x_2+x_3$'); axis((-5,5,-1,3.5))