# -*- coding: utf-8 -*-
"""
Created on Wed Feb 18 14:59:54 2015
how to generate realistic guitar chords using the Karplus-Strong Algorithm 
and discrete-time filters
fonte: 
www.mathworks.com/help/signal/examples/generating-guitar-chords-using-the-karplus-strong-algorithm.html
"""

import numpy as np
from scipy.special import sinc

def firls(N, f, D=None):
    """Least-squares FIR filter.
    N -- filter length, must be odd
    f -- list of tuples of band edges
       Units of band edges are Hz with 0.5 Hz == Nyquist
       and assumed 1 Hz sampling frequency
    D -- list of desired responses, one per band
    """
    if D is None:
        D = [1, 0]
    assert len(D) == len(f), "must have one desired response per band"
    assert N%2 == 1, 'filter length must be odd'
    L = (N-1)//2

    k = np.arange(L+1)
    k.shape = (1, L+1)
    j = k.T

    R = 0
    r = 0
    for i, (f0, f1) in enumerate(f):
        R += np.pi*f1*sinc(2*(j-k)*f1) - np.pi*f0*sinc(2*(j-k)*f0) + \
             np.pi*f1*sinc(2*(j+k)*f1) - np.pi*f0*sinc(2*(j+k)*f0)

        r += D[i]*(2*np.pi*f1*sinc(2*j*f1) - 2*np.pi*f0*sinc(2*j*f0))

    a = np.dot(np.linalg.inv(R), r)
    a.shape = (-1,)
    h = np.zeros(N)
    h[:L] = a[:0:-1]/2.
    h[L] = a[0]
    h[L+1:] = a[1:]/2.
    return h

def plot_response(h, name):
    H = np.fft.fft(h, 2000)
    f = np.arange(2000)/2000.
    figure()
    semilogy(f, abs(H))
    grid()
    setp(gca(), xlim=(0, .5))
    xlabel('frequency (Hz)')
    ylabel('magnitude')
    title(name)

#if __name__ == '__main__':
#    h = firls(31, [(0, .2), (.3, .5)])
#    from matplotlib.pyplot import *
#    plot_response(h, 'lowpass')
#
#    h = firls(51, [(0, .25), (.35, .5)], [0, 1])
#    plot_response(h, 'highpass')
#
#    h = firls(51, [(0, .1), (.2, .3), (.4, .5)], [0, 1, 0])
#    plot_response(h, 'bandpass')
#    show()
    
from matplotlib.pylab import plot, title, xlabel, ylabel, pi
from numpy import linspace, zeros, array, insert, append, log10, abs
from scipy.signal import firwin2, freqz
Fs       = 44100 # in sample/cycle
A        = 110.  # The A string of a guitar is normally tuned to 110 Hz
Eoffset  = -5
Doffset  = 5
Goffset  = 10
Boffset  = 14
E2offset = 19
F = linspace(1./Fs, 1000., 2**12)
x = zeros((Fs*4,1))

""" Playing a Note on an Open String

When a guitar string is plucked or strummed, it produces a sound wave
with peaks in the frequency domain that are equally spaced.  These are
called the harmonics and they give each note a full sound.  We can
generate sound waves with these harmonics with discrete-time filter
objects. """

delay = round(Fs/A) # feedback delay based on the first harmonic frequency

# Generate an IIR filter whose poles approximate the harmonics of the A string. 
# The zeros are added for subtle frequency domain shaping.
#b  = firls(42, [0 1/delay 2/delay 1], [0 0 1 1]); % FIR least squares filter
#a  = [1 zeros(1, delay) -0.5 -0.5]
FF = array([0.,1./delay,2./delay,1.]); GG = array([0,0,1,1])
b = firwin2(42, FF, GG, window='boxcar', antisymmetric=True)
#b = firls(43, [(0.,1./delay/2.),(2./delay/2.,1./2.)], [0,1])
a = zeros((1, delay),dtype=float); a = insert(a,0,1.); a = append(a,[-0.5,-0.5])
# show the magnitude response of the filter
W,H = freqz(b, a, 2*pi*F)
plot(W/(2*pi), 20*log10(abs(H))); title('Harmonics of an open A string')
xlabel('Frequency (Hz)');  ylabel('Magnitude (dB)')
