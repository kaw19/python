quads = []
for num in range(11):
	quads.append(num*num)
print(quads)
