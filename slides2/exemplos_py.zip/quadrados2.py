quads = [valor**2 for valor in range(1, 11)]
print(quads)