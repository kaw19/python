print("Linguagens:\nPython\nC\nJavaScript")
print()
print("Linguagens:\n\tPython\n\tC\n\tJavaScript")
