for n in range(5):
    print n