# Exercício 1 - Cap.5
# carro = 'subaru'
# print("Carro é 'subaru'? Eu prevejo True.")
# print(carro == 'subaru')
# print("Carro é 'audi'? Eu prevejo False.")
# print(carro == 'audi')

# lista_negra = ['andrew', 'joão', 'carolina']
# cliente = 'maria'
# print("Maria está na lista de devedores? Eu prevejo False.")
# print(cliente in lista_negra)
# print("Maria não é devedora? Eu prevejo True.")
# print(cliente not in lista_negra)

# Usuários de um site
usuarios = ['admin','joao','maria','carla','walter']
if usuarios:
	for usuario in usuarios:
		if usuario == 'admin':
			print('Olá Admin, você gostaria de ver um relatório de status?')
		else:
			print(f'Olá {usuario.title()}, obrigado por logar novamente.')
else:
	print('Ops! Não temos usuários cadastrados ainda!')
