jogadores = ['maria', 'marta', 'miguel', 'joão', 'eli']
# reservas = jogadores[:]  # cópia profunda: cada var. tem seu espaço de memória
reservas = jogadores       # cópia rasa: ambas var.s ocupam o mesmo espaço de mem.

print(jogadores,reservas)

jogadores.append("zico")

print(jogadores,reservas)