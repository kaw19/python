# -*- coding: utf-8 -*-
from numpy import arange, abs, angle, sin, exp, pi
from matplotlib.pylab import stem, subplot, xlabel, ylabel, axis
n = arange(-17,29)        # referência temporal
x = sin(pi*n/10.)         # sinal
N0 = 20.                  # período fundamental (qtde de amostras)
subplot(3,1,1); stem(n,x); xlabel('n'); ylabel('x[n]')
axis([-20,30,-1.2,1.2])
 
k = arange(-10,10)
C = []                    # lista de coeficientes espectrais
for n in arange(-20,44):
   termos = sin(n*pi/10.)*exp(-1.j*pi/10.*k*n)
   raia = sum(termos)/N0  # somatório de cada termo da série
   if abs(raia) < 0.0001: # ajuste de erro numérico
      raia = 0
   C.extend([raia])       # concatenação das raias espectrais

subplot(3,1,2); stem(arange(-20,44),abs(C))
xlabel('Freq. Discreta'); ylabel(u'Módulo')
subplot(3,1,3); stem(arange(-20,44),angle(C))
xlabel('Freq. Discreta'); ylabel('Fase')
