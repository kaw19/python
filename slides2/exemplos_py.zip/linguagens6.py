ling_favorita = {'márcia': 'java', 'joão': 'python', 'rubens': 'c', 'ana': 'fortran'}
print("Linguagens mais votadas na pesquisa:")
for ling in ling_favorita.values():
    print(ling.title(), end=', ')
print('...\n')