motos = ['honda', 'yamaha', 'suzuki']
print(f"A última moto que eu possuí foi uma {motos[-1].title()}.")
print(f"A última moto que eu possuí foi uma {motos[len(motos)-1].title()}.")