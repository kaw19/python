prenome   = "joão"
sobrenome = "josé"
nome      = f"{prenome} {sobrenome}"
mensagem  = f"Olá {nome.title()}! Tudo bem?"
print(mensagem)

# para versões anteriores a 3.6 use o método .format():
mensagem  = "Olá {}! Tudo bem?".format(nome.title())
print(mensagem)

#import this