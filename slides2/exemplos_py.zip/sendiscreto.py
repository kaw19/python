# -*- coding: utf-8 -*-
from numpy import arange, sin
from matplotlib.pylab import stem, xlabel, ylabel, title

n = arange(0,200)          # referência temporal
x = sin(n/10.)            # sinal
stem(n,x)
xlabel('n'); ylabel('x[n]')
title(u'Senóide de tempo discreto - Não Periódica') 