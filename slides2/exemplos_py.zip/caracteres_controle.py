print("Python")
print("\tPython")
print("\t\tPython")