jogadores = ['maria', 'marta', 'miguel', 'joão', 'eli']
print(jogadores[0:3])
