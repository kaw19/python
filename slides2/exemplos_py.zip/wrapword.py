# -*- coding: utf-8 -*-
"""
Created on Sat Apr 23 15:34:15 2022

@author: profc
"""

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER
from reportlab.lib import colors

# bodytext  style used for wrapping  data on flowables 
styles = getSampleStyleSheet()
styleN = styles["BodyText"]
styleN.alignment = TA_LEFT

styleBH = styles["Normal"]
styleBH.alignment = TA_CENTER


hdescripcion = Paragraph('''<b>descricão</b>''', styleBH)
hpartida = Paragraph('''<b>partida</b>''', styleBH)


descripcion = Paragraph('''long long long long long long long long long long 
long long long long long long long long long long line ''', styleN)
partida = Paragraph('1', styleN)
outro = "Texto sem quebra de linha, estoura limites..."

dados = [[hdescripcion, hpartida],[partida, descripcion],[2,outro]]

tabela = Table(dados,colWidths=(75,100))

tabela.setStyle(TableStyle([
                       ('INNERGRID', (0,0), (-1,-1), 0.25, colors.blue),
                       ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                       ]))

c = canvas.Canvas("wrapWord.pdf", pagesize=A4)
tabela.wrapOn(c, 30, 50)
tabela.drawOn(c, 100, 500)
c.save()
