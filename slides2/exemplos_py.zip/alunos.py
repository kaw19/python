alunos = ['justiniano machado dos santos',3,'frederico nunes rocha',1,'kaio flávio costa prata',2]
print(f"O aluno {alunos[0].title()} participou de {alunos[1]} aulas.")