# -*- coding: utf-8 -*-
"""
Created on Thu Aug 06 12:12:08 2015

@author: kaw
"""

import time, random
 
items = [unichr(i) for i in range(0x30a1,0x30ff + 1)] # símb.s do katakana
 
 
for i in range(1,11):                            # espaços e números
    items.append(str(i))
    items.append(" "*i)
 
def rain(row,column):                            # linhas,colunas
     for i in range(row):                        # para cada linha
         s = ''                                  # nova string
         for j in range(column):                 # p/ cada coluna (ou caracter)
             ri = random.randrange(len(items))   # índice aleatório
             s += items[ri]
         print(s)
         time.sleep(0.05) # ajuste o valor p/ simular adequadamente a chuva
         
rain(15,80)