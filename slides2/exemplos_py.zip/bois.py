pesos = [232, 245, 239, 410, 332, 222, 287]
print(f"Boi mais leve..: {min(pesos)} kg")
print(f"Boi mais pesado: {max(pesos)} kg")
print(f"Peso médio.....: {sum(pesos)/len(pesos)} kg")
print(f"Peso total.....: {sum(pesos)} kg")