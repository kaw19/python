escritores = ["Machado de Assis", "Clarice Lispector", "Guimarães Rosa"]
for escritor in escritores:
print(escritor, "é um excelente escritor brasileiro!")