carros = ['bmw', 'audi', 'toyota', 'subaru']
print("Lista original:", carros)
carros.reverse()
print("Lista inversa :", carros)
print("Lista ordenada:", sorted(carros))
carros.reverse()
print("Lista original:", carros)