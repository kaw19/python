escritores = ["Machado de Assis", "Clarice Lispector", 
			  "Guimarães Rosa", "Jorge Amado", "Graciliano Ramos", 
			  "Chico Buarque", "Carlos Drummond de Andrade", "Oswald de Andrade"]
for escritor in escritores:
   print(escritor, "é um excelente escritor brasileiro!")
   print(f"Eu gosto de ler as obras de {escritor.split()[0]}.\n")

print("\nParabéns a todos eles!\n")