pessoa = {
         'prenome':'cláudio', 
         'sobrenome':'fleury', 
         'idade':30, 
         'naturalidade':'goiânia'}
print(pessoa)