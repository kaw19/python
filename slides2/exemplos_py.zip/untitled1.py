# -*- coding: utf-8 -*-
"""
Created on Mon Oct 19 19:00:28 2015

@author: kaw
"""

from numpy import arange, ones, array, pi, exp, zeros, abs, angle
from matplotlib.pylab import stem, axis, title, xlabel, ylabel, grid, figure

N0 = 80; n = arange(0,N0); Omega = 2.*pi/N0
# Um período do sinal discreto x[n]
x = ones(N0);  x[N0/2:] = -1

# Um período do Espectro de Linhas (coef.s Série de Fourier)
c = zeros(N0,dtype=complex)
for k in range(0,N0):
    c[k] = sum(x*exp(-1j*k*n*Omega))/N0     # coef.s da S.F.

stem(n,abs(c)); axis([-1,N0,-0.2,1.2]), grid('on')
title(u'Espectro de Linhas – Janela Retangular')
xlabel(u'Harmônicos')
ylabel(u'Magnitude dos Coefic.s da Série de Fourier')
figure()
stem(n,angle(c)); axis([-1,N0,-1.9,1.9]), grid('on')
xlabel(u'Harmônicos')
ylabel(u'Fase dos Coefic.s da Série de Fourier (rad)')
