usuario0 = {'usuario': 'massis', 'prenome': 'machado de', 'sobrenome': 'assis',}
for chave, valor in usuario0.items():
	print(f"\nChave: {chave}")
	print(f"Valor: {valor}")