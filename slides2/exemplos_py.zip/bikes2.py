motos = ['honda', 'yamaha', 'suzuki']
print(motos)
motos[0] = 'ducati'
print(motos)