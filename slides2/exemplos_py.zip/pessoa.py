pessoa = {
          'prenome':'ana maria', 
          'sobrenome':'da silva',
          'idade':22,
          'cidade':'anápolis'
          }
print(f"Nome: {pessoa['prenome'].title()} {pessoa['sobrenome'].title()}\nIdade: " \
	  f"{pessoa['idade']}\nMora em: {pessoa['cidade'].title()}.")