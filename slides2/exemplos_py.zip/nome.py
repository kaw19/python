nome = "joão josé"
print(nome.title())