carros = ['bmw', 'audi', 'toyota', 'subaru']
print("Lista original :", carros)
carros.reverse()
print("Lista invertida:", carros)
print("Qtde de carros na lista:", len(carros))