nomes = ["mário",'joana','joão','mariana']
print(nomes[0].title(), nomes[1].title(), nomes[2].title(), nomes[3].title())