pares = list(range(2,21,2))
print(pares)
