# -*- coding: utf-8 -*-
"""
Torres de Hanói: tabuleiro com 3 pinos nos quais são encaixados discos  de
                 tamanho decrescente. O jogo consiste em mover os discos de um 
                 pino para outro, sendo que: só um disco é movido por vez, e
                 um disco maior não pode ser posto sobre um menor.
@author: kaw; 28.07.2017

Solução recursiva:

Algoritmo para mover N discos do pino A para o pino B usando o pino C
  se N == 1 então solução é trivial
  senão
     use o algoritmo para mover N-1 discos de A para C usando B
     mova o disco restante em A para B
     use o algoritmo para mover N-1 discos de C para B usando A
fim-algoritmo     
"""
def mover(X,Y):
    print "Mover disco de", X, " para", Y

def hanoi(n,A,B,C):         # move um disco de A para B usando C
    if n > 1:
        hanoi(n-1,A,C,B)    # move um disco de A para C usando B
    mover(A,B)
    if n > 1: 
        hanoi(n-1,C,B,A)    # move um disco de C para B usando A

hanoi(3,'A','B','C')        

''' Exemplo: 3 discos
   A      B      C
   |      |      |             |      |      |             |      |      |
   *      |      |             |      |      |             |      |      |
  ***     |      |    -->     ***     |      |    -->      |      |      |
 *****    |      |           *****    *      |           *****    *     ***
=====================       =====================       =====================

   |      |      |             |      |      |             |      |      |
   |      |      |             |      |      |             |      |      |
   |      |      *    -->      |      |      *    -->      |      |      |
 *****    |     ***            |    *****   ***            *    *****   ***
=====================       =====================       =====================

   |      |      |             |      |      |
   |      |      |             |      *      |
   |     ***     |    -->      |     ***     |
   *    *****    |             |    *****    |
=====================       =====================       =====================
'''