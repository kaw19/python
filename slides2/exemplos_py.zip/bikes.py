bikes = ['trek', 'cannondale', 'redline', 'specialized', 'rav']
print(bikes)
print(bikes[0])
print(bikes[0].title())
print(bikes[-1].title())
