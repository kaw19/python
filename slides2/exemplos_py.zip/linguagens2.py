linguagem_favorita = {
    'Márcia': 'java', 
    'João': 'python', 
    'Rubens': 'c', 
    'Ana': 'fortran'
    }
for nome, linguagem in linguagem_favorita.items():
    print(f"A linguagem favorita de {nome.title()} é {linguagem.title()}.")