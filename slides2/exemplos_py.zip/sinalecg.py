# -*- coding: utf-8 -*-
""" Lê amostras de 10s de um sinal de ECG gravadas em um arquivo no formato CSV
    (record cebsdb/b001 (I), from 0:00.000 to 0:10.000, 
     Combined measurement of ECG, Breathing and Seismocardiograms (cebsdb))
    @author: Prof. Cláudio, Fev/2015
    fonte: http://www.physionet.org/cgi-bin/atm/ATM """
import csv, sys
import numpy as np
import scipy.io as sio
import matplotlib.pylab as plt
ecg = np.zeros((1,50000))
with open('samples.csv', 'rb') as arq:
    amostras = csv.reader(arq)
    i = -2                      # qtde de linhas de cabeçalho
    for linha in amostras:
        if i >= 0:
            try:
                ecg[0,i] = float(linha[1])
                #print ecg[0,i]
            except csv.Error as e:
                sys.exit('[Erro] Arq. %s, linha %d: %s' % \
                         (amostras.filename, amostras.line_num, e))
        i += 1
A = ecg.size                        # qtde de amostras
N = 10./A; fs = 1./N                # freq. de amostragem
n = np.arange(0,10,N)               # base temporal ( n = np.linspace(0,10,10*fs))
#rb = 0.025*np.random.randn(1,A)     # ruído branco
#ecgr1 = ecg + rb
r1 = 0.4*np.sin(2*np.pi*n*1.)       # ruído passeio (wander)
r2 = 0.3*np.cos(2*np.pi*n*60.)      # ruído da rede (60 Hz)
r3 = r1 + r2                        # composição de ruídos
r4 = 0.5*np.sin(2*np.pi*n*100.)     # ruído de alta freq.
#plt.plot(n,rp)
ecgr1 = ecg + r1
ecgr2 = ecg + r2
ecgr3 = ecg + r3
ecgr4 = ecg + r4

ps = np.abs(np.fft.fft(ecg))**2     # espectro de potência do sinal original
psr = np.abs(np.fft.fft(ecgr1))**2  # espectro de potência do sinal ruidoso
f = np.fft.fftfreq(A,N)

plt.title('Sinal de ECG')
plt.subplot(2,1,1); plt.plot(n,ecg[0,:]); plt.ylabel('Sinal Original')
plt.subplot(2,1,2); plt.plot(n,ecgr1[0,:]); plt.ylabel('Sinal Ruidoso')
plt.figure()
plt.title(u'Espectro de Potência - Sinal de ECG')
plt.subplot(2,1,1); plt.plot(f,ps[0,:]); plt.ylabel('Sinal Original')
plt.subplot(2,1,2); plt.plot(f,psr[0,:]); plt.ylabel('Sinal Ruidoso')

sio.savemat('ecg.mat',{'ecg1': ecgr1,'ecg2': ecgr2,'ecg3': ecgr3,'ecg4': ecgr4})
s = sio.loadmat('ecg.mat')
plt.figure(); plt.plot(s['ecg4'][0])
