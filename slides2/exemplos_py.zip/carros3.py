fabr_carros = ['bmw', 'audi', 'fnm', 'toyota', 'subaru']

for fabr in fabr_carros:
	if fabr in ['bmw', 'fnm']:       # if fabr == 'bmw' or fabr == 'fnm':
		print(fabr.upper())
	else:
		print(fabr.title())