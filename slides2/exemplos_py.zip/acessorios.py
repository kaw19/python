acessorios = [] #['relógio','óculos','chapéu','anel']
if acessorios:
    for item in acessorios:
        print("Coloque ", item)
else: 
    print("Vc não tem acessório!")