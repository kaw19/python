prenome   = "joão"
sobrenome = "josé"
nome      = f"{prenome} {sobrenome}"
print(nome)

#print(f"Olá {nome.title()}! Tudo bem?")