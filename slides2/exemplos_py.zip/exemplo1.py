# -*- coding: utf-8 -*-
"""
Created on Sat Apr 23 14:08:17 2022

@author: profc
"""

from reportlab.platypus.doctemplate import SimpleDocTemplate
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle

texto = '''Você é acusado de, no dia 28 de maio de 1970,
voluntariamente, ilegalmente e com malícia de premeditação, 
publicar um suposto livro de frases inglês-húngaro com a 
intenção de causar uma violação da paz. Como você se declara?'''

estilo1 = ParagraphStyle('Normal')
p = Paragraph(texto, estilo1)
conteudo = []
conteudo.append(p)
doc = SimpleDocTemplate("exemplo1.pdf")
doc.build(conteudo)
