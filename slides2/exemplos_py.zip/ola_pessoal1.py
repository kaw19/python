print("Olá Pessoal! Sejam bem-vindos ao curso de Python!")
