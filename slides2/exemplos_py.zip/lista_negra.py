lista_negra = ['andrew', 'carolina', 'david']      # clientes devedores

usuario = 'maria'                                  # usuário do pedido 
if usuario not in lista_negra:
   print(f"{usuario.title()}, você pode pagar seu pedido com cartão de crédito...")