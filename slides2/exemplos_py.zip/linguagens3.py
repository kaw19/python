linguagem_favorita = {
    'Márcia': 'java', 
    'João': 'python', 
    'Rubens': 'c', 
    'Ana': 'fortran'
    }
for nome in linguagem_favorita.keys():   # linguagem_favorita
    print(nome.title())