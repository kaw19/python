# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 19:51:50 2015

@author: kaw
"""
from matplotlib.pylab import plot, setp, xlabel, ylabel, title, \
                             grid, figure, draw, gca, legend
from numpy import arange
plot(range(10))
xlabel('medido')
ylabel('calculado')
title('Medido vs. Calculado')
grid(True)
meugraf = gca()          # pega uma referência do gráfico (plot)
linha = meugraf.lines[0] # pega ref. da primeira linha
linha.set_marker('o')    # ajusta propriedades usando mét.s 'set_algumacoisa'
setp(linha, color='g')   # ou usando a função 'setp'
draw()                   # aplica novas propriedades e redesenha a figura
x = arange(100)
linear = arange(100)
quadrado = [v * v for v in arange(0, 10, 0.1)]
plot(x, linear, x, quadrado)  # adiciona linhas em um gráfico
legend(('linear', 'quadrado'))
figure()                    # limpa o gráfico antigo (clf)
plot(x, linear, 'g:+', x, quadrado, 'r--o')
leg = legend(('linear', 'quadrado'), loc='upper left')
