ling_favorita = {
    'márcia': 'java', 
    'joão': 'python', 
    'rubens': 'c', 
    'ana': 'fortran'}

for nome in sorted(ling_favorita.keys()):
    print(f"{nome.title()}, obrigado por participar da pesquisa.")