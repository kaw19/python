ling_favorita = {'márcia':'java', 'joão':'python', 'rubens':'c'}
novos = {'luiz':'c', 'ana':'python'}
ling_favorita.update(novos)
print(ling_favorita)
print(novos)