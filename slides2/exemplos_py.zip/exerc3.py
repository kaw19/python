transp = ["moto",'carro','bike','ônibus']
print("O transporte mais barato é", transp[-2].title())
print("O transporte mais barato em longas distâncias é", transp[-1].title())
print("O transporte mais rápido é", transp[0].title())
print("O transporte mais confortável é", transp[1].title())